package com.example.actividad1503

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun abrirEstudiante (@Suppress("UNUSED_PARAMETER")view: View){
        val intent = Intent(this,EstudiantesActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun abrirProfesor (@Suppress("UNUSED_PARAMETER")view: View){
        val intent = Intent(this,ProfesoresActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun fichaHeroe (@Suppress("UNUSED_PARAMETER")view: View){
        val intent = Intent(this,FichaActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun formuHeroe (@Suppress("UNUSED_PARAMETER")view: View){
        val intent = Intent(this,FormularioActivity::class.java).apply {  }
        startActivity(intent)
    }
}