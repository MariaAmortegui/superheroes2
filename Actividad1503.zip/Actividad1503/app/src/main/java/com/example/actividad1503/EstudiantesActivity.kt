package com.example.actividad1503

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class EstudiantesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_estudiantes)
    }
    fun abrirHeroe (@Suppress("UNUSED_PARAMETER")view: View){
        val intent = Intent(this,MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun abrirProfesor (@Suppress("UNUSED_PARAMETER")view: View){
        val intent = Intent(this,ProfesoresActivity::class.java).apply {  }
        startActivity(intent)
    }
}